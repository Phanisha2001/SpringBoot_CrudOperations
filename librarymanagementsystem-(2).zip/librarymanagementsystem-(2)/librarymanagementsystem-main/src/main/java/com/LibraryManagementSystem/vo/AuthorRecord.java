package com.LibraryManagementSystem.vo;

public record AuthorRecord(Long id, String name, String description) {

}
