package com.LibraryManagementSystem.vo;

public record CategoryRecord(Long id,String name) {

}
