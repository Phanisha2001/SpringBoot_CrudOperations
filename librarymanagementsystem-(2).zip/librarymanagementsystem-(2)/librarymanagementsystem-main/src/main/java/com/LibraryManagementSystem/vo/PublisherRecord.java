package com.LibraryManagementSystem.vo;

public record PublisherRecord(Long id, String name) {

}
